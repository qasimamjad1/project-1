﻿using System;
using System.Collections.Generic;

namespace BankAccountManagementSystem
{
    // BankAccount class as an abstraction of a bank account
    public class BankAccount
    {
        private string accountNumber; // Private field to store the account number
        private string accountHolderName; // Private field to store the account holder's name
        private decimal balance; // Private field to store the account balance
        private List<Transaction> transactions; // Private field to store the transaction history

        // Public property to get the account number
        public string AccountNumber
        {
            get { return accountNumber; }
            private set { accountNumber = value; }
        }

        // Public property to get or set the account holder's name
        public string AccountHolderName
        {
            get { return accountHolderName; }
            set { accountHolderName = value; }
        }

        // Public property to get the account balance
        public decimal Balance
        {
            get { return balance; }
            private set { balance = value; }
        }

        // Constructor to initialize the BankAccount object
        public BankAccount(string accountNumber, string accountHolderName, decimal initialBalance)
        {
            AccountNumber = accountNumber;
            AccountHolderName = accountHolderName;
            Balance = initialBalance;
            transactions = new List<Transaction>(); // Initialize an empty transaction list
        }

        // Deposit method overload
        public void Deposit(decimal amount)
        {
            Deposit(amount, "Deposit"); // Call the Deposit method with the default description
        }

        // Deposit method
        public void Deposit(decimal amount, string description)
        {
            if (amount <= 0)
            {
                Console.WriteLine("Deposit amount must be greater than zero.");
                return;
            }

            Balance += amount; // Increase the balance by the deposit amount
            AddTransaction(amount, description); // Add the transaction to the transaction history
        }

        // Withdraw method overload
        public void Withdraw(decimal amount)
        {
            Withdraw(amount, "Withdrawal"); // Call the Withdraw method with the default description
        }

        // Withdraw method
        public virtual void Withdraw(decimal amount, string description)
        {
            if (amount <= 0)
            {
                Console.WriteLine("Withdrawal amount must be greater than zero.");
                return;
            }

            if (amount > Balance)
            {
                Console.WriteLine("Insufficient funds.");
                return;
            }

            Balance -= amount; // Decrease the balance by the withdrawal amount
            AddTransaction(-amount, description); // Add the transaction to the transaction history
        }

        // Protected method to add a transaction to the transaction history
        protected void AddTransaction(decimal amount, string description)
        {
            Transaction transaction = new Transaction(amount, description);
            transactions.Add(transaction);
        }

        // Virtual method to calculate the interest (to be overridden in derived classes)
        public virtual void CalculateInterest()
        {
            // Default interest calculation for the base BankAccount class
            Console.WriteLine("Interest calculated based on the base BankAccount class.");
        }

        // Method to print the account statement
        public void PrintStatement()
        {
            Console.WriteLine($"Account Number: {AccountNumber}");
            Console.WriteLine($"Account Holder: {AccountHolderName}");
            Console.WriteLine($"Balance: {Balance:C}");
            Console.WriteLine("Transaction History:");

            foreach (Transaction transaction in transactions)
            {
                Console.WriteLine(transaction);
            }
        }
    }

    // Subclass SavingsAccount inheriting from BankAccount
    public class SavingsAccount : BankAccount, ITransaction
    {
        public SavingsAccount(string accountNumber, string accountHolderName, decimal initialBalance)
            : base(accountNumber, accountHolderName, initialBalance)
        {
        }

        // Override method to calculate the interest for a savings account
        public override void CalculateInterest()
        {
            decimal interestRate = 0.05m;
            decimal interest = Balance * interestRate;
            Deposit(interest, "Interest Deposit");
        }

        // Implementation of the ITransaction interface method
        public void ExecuteTransaction(decimal amount)
        {
            if (amount >= 0)
            {
                Deposit(amount, "Transaction");
            }
            else
            {
                Withdraw(-amount, "Transaction");
            }
        }

        // Implementation of the ITransaction interface method
        public void PrintTransaction()
        {
            Console.WriteLine("Transaction Details: Savings Account");
        }
    }

    // Subclass CheckingAccount inheriting from BankAccount
    public class CheckingAccount : BankAccount, ITransaction
    {
        public CheckingAccount(string accountNumber, string accountHolderName, decimal initialBalance)
            : base(accountNumber, accountHolderName, initialBalance)
        {
        }

        // Override method to calculate the interest for a checking account
        public override void CalculateInterest()
        {
            Console.WriteLine("No interest calculated for Checking Account.");
        }

        // Implementation of the ITransaction interface method
        public void ExecuteTransaction(decimal amount)
        {
            if (amount >= 0)
            {
                Deposit(amount, "Transaction");
            }
            else
            {
                Withdraw(-amount, "Transaction");
            }
        }

        // Implementation of the ITransaction interface method
        public void PrintTransaction()
        {
            Console.WriteLine("Transaction Details: Checking Account");
        }
    }

    // Subclass LoanAccount inheriting from BankAccount
    public class LoanAccount : BankAccount, ITransaction
    {
        public LoanAccount(string accountNumber, string accountHolderName, decimal initialBalance)
            : base(accountNumber, accountHolderName, initialBalance)
        {
        }

        // Override method to calculate the interest for a loan account
        public override void CalculateInterest()
        {
            decimal interestRate = 0.1m;
            decimal interest = Balance * interestRate;
            Deposit(interest, "Interest Deposit");
        }

        // Implementation of the ITransaction interface method
        public void ExecuteTransaction(decimal amount)
        {
            if (amount >= 0)
            {
                Deposit(amount, "Transaction");
            }
            else
            {
                Withdraw(-amount, "Transaction");
            }
        }

        // Implementation of the ITransaction interface method
        public void PrintTransaction()
        {
            Console.WriteLine("Transaction Details: Loan Account");
        }
    }

    // Transaction class to store transaction details
    public class Transaction
    {
        public decimal Amount { get; } // Public property to get the transaction amount
        public string Description { get; } // Public property to get the transaction description

        // Constructor to initialize the Transaction object
        public Transaction(decimal amount, string description)
        {
            Amount = amount;
            Description = description;
        }

        // Override method to convert the Transaction object to a string representation
        public override string ToString()
        {
            return $"{Description}: {Amount:C}";
        }
    }

    // ITransaction interface defining methods for executing and printing transactions
    public interface ITransaction
    {
        void ExecuteTransaction(decimal amount);
        void PrintTransaction();
    }

    // Bank class managing different bank accounts
    public class Bank
    {
        private Dictionary<string, BankAccount> bankAccounts; // Private dictionary to store bank accounts

        // Constructor to initialize the Bank object
        public Bank()
        {
            bankAccounts = new Dictionary<string, BankAccount>(); // Initialize an empty bank account dictionary
        }

        // Method to add a bank account to the bank
        public void AddBankAccount(BankAccount account)
        {
            bankAccounts.Add(account.AccountNumber, account);
        }

        // Method to get a bank account by account number
        public BankAccount GetBankAccount(string accountNumber)
        {
            if (bankAccounts.ContainsKey(accountNumber))
            {
                return bankAccounts[accountNumber];
            }

            return null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank();

            // Creating instances of different account types
            SavingsAccount savingsAccount = new SavingsAccount("SA001", "John Doe", 5000m);
            CheckingAccount checkingAccount = new CheckingAccount("CA001", "Jane Smith", 2000m);
            LoanAccount loanAccount = new LoanAccount("LA001", "Alice Johnson", 10000m);

            // Adding the bank accounts to the bank
            bank.AddBankAccount(savingsAccount);
            bank.AddBankAccount(checkingAccount);
            bank.AddBankAccount(loanAccount);

            // Performing transactions and printing statements
            savingsAccount.Deposit(1000m);
            savingsAccount.Withdraw(500m);
            savingsAccount.CalculateInterest();
            savingsAccount.PrintStatement();

            Console.WriteLine();

            checkingAccount.Deposit(200m);
            checkingAccount.Withdraw(300m);
            checkingAccount.PrintStatement();

            Console.WriteLine();

            loanAccount.Withdraw(500m);
            loanAccount.CalculateInterest();
            loanAccount.PrintStatement();

            Console.WriteLine();

            // Testing polymorphism and interface implementation
            ITransaction transaction1 = new SavingsAccount("SA002", "Mark Davis", 5000m);
            transaction1.ExecuteTransaction(1000m);
            transaction1.PrintTransaction();

            Console.WriteLine();

            ITransaction transaction2 = new CheckingAccount("CA002", "Amy Johnson", 2000m);
            transaction2.ExecuteTransaction(-500m);
            transaction2.PrintTransaction();

            Console.WriteLine();

            ITransaction transaction3 = new LoanAccount("LA002", "Michael Smith", 10000m);
            transaction3.ExecuteTransaction(-1000m);
            transaction3.PrintTransaction();
            Console.ReadLine();
        }
    }
}
