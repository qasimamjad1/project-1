﻿using System;

class Program
{
    static void Main()
    {
        // Ask the user to enter a sentence
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        // Split the sentence into an array of words
        string[] words = sentence.Split(' ');

        // Iterate through each word in the array
        foreach (string word in words)
        {
            // Check if the word is a palindrome
            if (IsPalindrome(word))
            {
                // Display the palindromic word to the user
                Console.WriteLine("The Palindrome Word is : "+ word);
            }
        }
        Console.ReadKey();
    }

    static bool IsPalindrome(string word)
    {
        int left = 0;//left represents the index of the leftmost character in the word. It is initially set to 0, indicating the first character of the word.
        int right = word.Length - 1;//right represents the index of the rightmost character in the word. It is initialized as word.Length - 1, where word.Length gives the total number of characters in the word. By subtracting 1, we get the index of the last character in the word.

        while (left < right)
        {
            // Compare the characters at the left and right positions
            if (word[left] != word[right])
            {
                return false; // If characters don't match, it's not a palindrome
            }

            left++; // Move to the next character from the left
            right--; // Move to the next character from the right
        }

        return true; // If the loop completes, it's a palindrome
    }
}
