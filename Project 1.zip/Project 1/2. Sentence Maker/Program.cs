﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        string[] words = sentence.Split(' ');

        Console.WriteLine("Enter the number of sentences to generate:");
        int n = Convert.ToInt32(Console.ReadLine());

        Random random = new Random();
        for (int i = 0; i < n; i++)
        {
            string generatedSentence = GenerateSentence(words, random);
            Console.WriteLine(generatedSentence);
        }
        Console.ReadKey();
    }

    static string GenerateSentence(string[] words, Random random)
    {
        int wordCount = 5;
        List<string> chosenWords = new List<string>();

        for (int i = 0; i < wordCount; i++)
        {
            int randomIndex = random.Next(words.Length);
            string randomWord = words[randomIndex];
            chosenWords.Add(randomWord);
        }

        string generatedSentence = string.Join(" ", chosenWords);
        return generatedSentence;
    }
}
