﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        string[] words = sentence.Split(' '); // Split the sentence into an array of words

        Dictionary<string, int> wordFrequencies = GetWordFrequencies(words); // Calculate the frequency of each word

        Console.WriteLine("Word Frequencies:");
        foreach (var kvp in wordFrequencies)
        {
            Console.WriteLine($"{kvp.Key}: {kvp.Value}");
        }
        Console.ReadKey();
    }

    static Dictionary<string, int> GetWordFrequencies(string[] words)
    {
        Dictionary<string, int> wordFrequencies = new Dictionary<string, int>();

        foreach (string word in words)
        {
            if (wordFrequencies.ContainsKey(word))
            {
                wordFrequencies[word]++; // Increment the frequency if the word already exists
            }
            else
            {
                wordFrequencies[word] = 1; // Add the word to the dictionary with a frequency of 1
            }
        }

        return wordFrequencies;
    }
}
