﻿using System;

class Program
{
    static void Main()
    {
        // Ask the user to enter a sentence
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        // Split the sentence into an array of words
        string[] words = sentence.Split(' ');

        // Iterate through each word in the array
        foreach (string word in words)
        {
            // Calculate the number of vowels and consonants for the current word
            int vowelCount = CountVowels(word);
            int consonantCount = word.Length - vowelCount;

            // Display the vowel and consonant counts for the current word
            Console.WriteLine($"Word: {word}");
            Console.WriteLine($"Vowels: {vowelCount}");
            Console.WriteLine($"Consonants: {consonantCount}");
            Console.WriteLine();
        }
        Console.ReadKey();
    }

    static int CountVowels(string word)
    {
        // Convert the word to lowercase for case-insensitive comparison
        word = word.ToLower();

        // Define a string of all vowels
        string vowels = "aeiou";

        int vowelCount = 0;

        // Iterate through each character in the word
        foreach (char c in word)
        {
            // Check if the character is a vowel
            if (vowels.Contains(c.ToString()))
            {
                vowelCount++; // Increment the vowel count
            }
        }

        return vowelCount;
    }
}
