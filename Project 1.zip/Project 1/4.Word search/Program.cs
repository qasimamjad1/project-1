﻿using System;

class Program
{
    static void Main()
    {
        // Ask the user to enter a sentence
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        // Ask the user to enter a word for search
        Console.WriteLine("Enter a word to search:");
        string searchWord = Console.ReadLine();

        // Convert both the sentence and search word to lowercase for case-insensitive search
        string lowerCaseSentence = sentence.ToLower();
        string lowerCaseSearchWord = searchWord.ToLower();

        // Initialize a variable to count the number of occurrences of the search word
        int count = 0;

        // Split the sentence into an array of words
        string[] words = lowerCaseSentence.Split(' ');

        // Iterate through each word in the array
        foreach (string word in words)
        {
            // Check if the word matches the search word
            if (word == lowerCaseSearchWord)
            {
                count++; // Increment the count if a match is found
            }
        }

        // Check if any occurrences of the search word were found
        if (count > 0)
        {
            Console.WriteLine($"The word '{searchWord}' appears {count} time(s) in the sentence.");
        }
        else
        {
            Console.WriteLine($"The word '{searchWord}' does not appear in the sentence.");
        }
        Console.ReadKey();
    }
    
}
