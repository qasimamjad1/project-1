﻿using System;

class Program
{
    static void Main()
    {
        // Ask the user to enter a sentence
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        // Split the sentence into an array of words
        string[] words = sentence.Split(' ');

        // Initialize variables to keep track of the longest and shortest words
        string longestWord = "";//innitialize as empty strings
        string shortestWord = "";

        // Iterate through each word in the array
        foreach (string word in words)
        {
            // Check if the current word is longer than the longest word found so far
            if (word.Length > longestWord.Length)
            {
                longestWord = word;
            }
            // Check if the current word is shorter than the shortest word found so far
            else if (word.Length < shortestWord.Length || shortestWord == "")
            {
                shortestWord = word;
            }
        }

        // Display the longest and shortest words
        Console.WriteLine("Longest Word(s):");
        foreach (string word in words)
        {
            if (word.Length == longestWord.Length)
            {
                Console.WriteLine(word);
            }
        }

        Console.WriteLine("Shortest Word(s):");
        foreach (string word in words)
        {
            if (word.Length == shortestWord.Length)
            {
                Console.WriteLine(word);
            }
        }
        Console.ReadKey();
    }
}
